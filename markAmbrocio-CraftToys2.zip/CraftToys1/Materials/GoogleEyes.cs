﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CraftToys1
{
    class GoogleEyes : Material
    {
        public GoogleEyes(string _name, double _cost) : base(_name, _cost)
        {
            MaterialName = "Google Eyes";
        }
    }
}
