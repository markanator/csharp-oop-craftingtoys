﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CraftToys1
{
    class POMPOM : Material
    {
        public POMPOM(string _name, double _cost) : base(_name, _cost)
        {
            MaterialName = "POMPOM";
        }
    }
}
