﻿/*
 * BY: MARK AMBROCIO
 * ASCII Text from: https://www.patorjk.com/
 * 
 */
using System;
using static System.Console;

namespace CraftToys1
{
    class Program
    {
        static void Main(string[] args)
        {
            Title = "Mark Ambrocio\'s Toy Crafter 300X v2";
            
            new PIPBOY();
        }
    }
}
